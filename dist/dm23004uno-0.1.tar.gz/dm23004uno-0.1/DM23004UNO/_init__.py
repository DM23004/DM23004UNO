# Este archivo permite importar los módulos desde la librería
from .lineal import *
from .iterativos import *
from .no_lineal import *
